$ErrorActionPreference = "Stop"
Set-StrictMode -Version 2.0

$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ScriptDirectory)) {
    $ScriptDirectory = (Get-Location).Path
}

$CutokDirectory = Join-Path $ScriptDirectory "cutok"
$ManifestFile = Join-Path $ScriptDirectory "cutok_manifest.js"
$AllowedExtensions = @(".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".avif")
$ImageUrls = @()

if (Test-Path -LiteralPath $CutokDirectory -PathType Container) {
    $CutokRoot = $CutokDirectory.TrimEnd("\") + "\"
    $ImageUrls = @(
        Get-ChildItem -LiteralPath $CutokDirectory -File -Recurse |
            Where-Object { $AllowedExtensions -contains $_.Extension.ToLowerInvariant() } |
            Sort-Object FullName |
            ForEach-Object {
                $RelativePath = $_.FullName.Substring($CutokRoot.Length)
                $EncodedParts = @(
                    $RelativePath.Split("\") | ForEach-Object {
                        [Uri]::EscapeDataString($_)
                    }
                )
                "cutok/" + ($EncodedParts -join "/")
            }
    )
}

$Json = ConvertTo-Json -InputObject @($ImageUrls) -Compress
$Content = "// Generated automatically. Do not edit.`r`nwindow.CUTOK_IMAGE_FILES = $Json;`r`n"
$Utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($ManifestFile, $Content, $Utf8WithoutBom)

Write-Host ("cutok images found: " + $ImageUrls.Count)
exit 0
