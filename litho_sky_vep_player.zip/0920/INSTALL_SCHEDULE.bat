@echo off
setlocal
set "SCRIPT=%~dp0INSTALL_DAILY_0100_0102.ps1"

if not exist "%SCRIPT%" (
    echo [ERROR] INSTALL_DAILY_0100_0102.ps1 was not found.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
exit /b %ERRORLEVEL%
