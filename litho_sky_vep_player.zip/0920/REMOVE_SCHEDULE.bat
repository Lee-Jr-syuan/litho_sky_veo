@echo off
setlocal
set "SCRIPT=%~dp0REMOVE_DAILY_SCHEDULE.ps1"

if not exist "%SCRIPT%" (
    echo [ERROR] REMOVE_DAILY_SCHEDULE.ps1 was not found.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
exit /b %ERRORLEVEL%
