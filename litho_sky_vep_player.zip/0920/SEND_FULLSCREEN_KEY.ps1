param(
    [Parameter(Mandatory = $true)]
    [string]$EdgeProfile,

    [int]$DelaySeconds = 10
)

$ErrorActionPreference = "Stop"
$LogFile = Join-Path $PSScriptRoot "last_launch_mode.txt"

function Write-LaunchLog {
    param([string]$Message)
    Add-Content -LiteralPath $LogFile -Value ("{0} {1}" -f $Message, (Get-Date -Format "yyyy-MM-dd HH:mm:ss")) -Encoding ASCII
}

try {
    Start-Sleep -Seconds ([Math]::Max(0, $DelaySeconds))

    $Deadline = (Get-Date).AddSeconds(20)
    $Edge = $null

    do {
        $Edge = Get-CimInstance Win32_Process |
            Where-Object {
                $_.Name -eq "msedge.exe" -and
                $_.CommandLine -and
                $_.CommandLine.IndexOf($EdgeProfile, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and
                $_.CommandLine.IndexOf("--kiosk", [StringComparison]::OrdinalIgnoreCase) -ge 0
            } |
            Select-Object -First 1

        if (-not $Edge) {
            Start-Sleep -Seconds 1
        }
    } while (-not $Edge -and (Get-Date) -lt $Deadline)

    if (-not $Edge) {
        Write-LaunchLog "AUTO_H_FAILED_EDGE_NOT_FOUND"
        exit 1
    }

    $Shell = New-Object -ComObject WScript.Shell
    if (-not $Shell.AppActivate([int]$Edge.ProcessId)) {
        Write-LaunchLog "AUTO_H_FAILED_ACTIVATE"
        exit 2
    }

    Start-Sleep -Milliseconds 750
    $Shell.SendKeys("h")
    Write-LaunchLog "AUTO_H_SENT"
    exit 0
} catch {
    Write-LaunchLog ("AUTO_H_FAILED " + $_.Exception.Message)
    exit 3
}
