@echo off
setlocal

set "HTML=%~dp0index.html"
set "MANIFEST_BUILDER=%~dp0BUILD_CUTOK_MANIFEST.ps1"
set "SERVER_SCRIPT=%~dp0EXHIBITION_SERVER.ps1"
set "EDGE_PROFILE=%LOCALAPPDATA%\ExhibitionHTML\EdgeProfile"

if not exist "%HTML%" (
    echo.
    echo [ERROR] index.html was not found beside this BAT file.
    echo Expected: %HTML%
    echo.
    pause
    exit /b 1
)

if not exist "%MANIFEST_BUILDER%" (
    echo.
    echo [ERROR] BUILD_CUTOK_MANIFEST.ps1 was not found beside this BAT file.
    echo.
    pause
    exit /b 1
)

if not exist "%SERVER_SCRIPT%" (
    echo.
    echo [ERROR] EXHIBITION_SERVER.ps1 was not found beside this BAT file.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%MANIFEST_BUILDER%"
if errorlevel 1 (
    echo.
    echo [ERROR] Could not scan the cutok folder.
    echo.
    pause
    exit /b 1
)

set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"

if not exist "%EDGE%" (
    echo.
    echo [ERROR] Microsoft Edge was not found.
    echo.
    pause
    exit /b 1
)

set "EXHIBITION_SERVER_SCRIPT=%SERVER_SCRIPT%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p=$env:EXHIBITION_SERVER_SCRIPT; Get-CimInstance Win32_Process ^| Where-Object { ($_.Name -eq 'powershell.exe' -or $_.Name -eq 'pwsh.exe') -and $_.CommandLine -and $_.CommandLine.IndexOf($p,[StringComparison]::OrdinalIgnoreCase) -ge 0 } ^| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
timeout /t 1 /nobreak >nul
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%SERVER_SCRIPT%" -Port 18765
timeout /t 2 /nobreak >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:18765/health' -TimeoutSec 3; if ($r.StatusCode -eq 200) { exit 0 }; exit 1 } catch { exit 1 }"
if errorlevel 1 (
    echo.
    echo [ERROR] The local exhibition server could not start on port 18765.
    echo.
    pause
    exit /b 1
)

set "HTML_URL=http://127.0.0.1:18765/index.html"
REM Automatic startup must enter the HTML system's own full-screen preview,
REM not only Edge kiosk mode.  exhibition=1 hides the editor controls and
REM fills the screen with the 1920x1080 output canvas; preview=1 enables that
REM output canvas while keeping the saved displacement, scale and angle.
set "KIOSK_URL=%HTML_URL%?loop=1&exhibition=1&preview=1"

if /I "%~1"=="kiosk" (
    > "%~dp0last_launch_mode.txt" echo KIOSK %date% %time%
    REM Edge ignores kiosk flags when this dedicated profile is already open.
    REM Close only the exhibition Edge profile; normal Edge windows are untouched.
    set "EXHIBITION_EDGE_PROFILE=%EDGE_PROFILE%"
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
      "$p=$env:EXHIBITION_EDGE_PROFILE; Get-CimInstance Win32_Process ^| Where-Object { $_.Name -eq 'msedge.exe' -and $_.CommandLine -and $_.CommandLine.IndexOf($p,[StringComparison]::OrdinalIgnoreCase) -ge 0 } ^| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
    timeout /t 2 /nobreak >nul

    start "" "%EDGE%" ^
      --user-data-dir="%EDGE_PROFILE%" ^
      --allow-file-access-from-files ^
      --kiosk "%KIOSK_URL%" ^
      --edge-kiosk-type=fullscreen ^
      --start-fullscreen ^
      --no-first-run ^
      --disable-session-crashed-bubble ^
      --autoplay-policy=no-user-gesture-required

    REM Send H from a separate hidden process after Edge and the images load.
    start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden ^
      -File "%~dp0SEND_FULLSCREEN_KEY.ps1" -EdgeProfile "%EDGE_PROFILE%" -DelaySeconds 10
    exit /b 0
)

> "%~dp0last_launch_mode.txt" echo SETUP %date% %time%
start "" "%EDGE%" ^
  --user-data-dir="%EDGE_PROFILE%" ^
  --allow-file-access-from-files ^
  --no-first-run ^
  "%HTML_URL%"
exit /b 0
