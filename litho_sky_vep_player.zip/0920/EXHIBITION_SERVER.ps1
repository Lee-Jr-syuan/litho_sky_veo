[CmdletBinding()]
param(
    [int]$Port = 18765
)

$ErrorActionPreference = "Stop"
$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ScriptDirectory)) {
    $ScriptDirectory = (Get-Location).Path
}

$RootPath = [System.IO.Path]::GetFullPath($ScriptDirectory).TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
$StateFile = Join-Path $ScriptDirectory "exhibition_state.json"
$Utf8 = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false

function Read-HttpRequest {
    param([System.Net.Sockets.NetworkStream]$Stream)

    $buffer = New-Object byte[] 8192
    $memory = New-Object System.IO.MemoryStream
    $headerEnd = -1

    while ($headerEnd -lt 0) {
        $read = $Stream.Read($buffer, 0, $buffer.Length)
        if ($read -le 0) { return $null }
        $memory.Write($buffer, 0, $read)
        if ($memory.Length -gt 1048576) { throw "HTTP headers are too large." }

        $data = $memory.ToArray()
        $start = [Math]::Max(0, $data.Length - $read - 4)
        for ($i = $start; $i -le $data.Length - 4; $i++) {
            if ($data[$i] -eq 13 -and $data[$i + 1] -eq 10 -and $data[$i + 2] -eq 13 -and $data[$i + 3] -eq 10) {
                $headerEnd = $i
                break
            }
        }
    }

    $allData = $memory.ToArray()
    $headerText = [System.Text.Encoding]::ASCII.GetString($allData, 0, $headerEnd)
    $headerLines = $headerText -split "`r`n"
    $requestParts = $headerLines[0] -split " "
    if ($requestParts.Length -lt 2) { throw "Invalid HTTP request line." }

    $headers = @{}
    for ($i = 1; $i -lt $headerLines.Length; $i++) {
        $separator = $headerLines[$i].IndexOf(":")
        if ($separator -gt 0) {
            $name = $headerLines[$i].Substring(0, $separator).Trim().ToLowerInvariant()
            $value = $headerLines[$i].Substring($separator + 1).Trim()
            $headers[$name] = $value
        }
    }

    $contentLength = 0
    if ($headers.ContainsKey("content-length")) {
        $contentLength = [Math]::Max(0, [int]$headers["content-length"])
    }

    $body = New-Object byte[] $contentLength
    $bodyStart = $headerEnd + 4
    $alreadyRead = [Math]::Min($contentLength, $allData.Length - $bodyStart)
    if ($alreadyRead -gt 0) {
        [System.Array]::Copy($allData, $bodyStart, $body, 0, $alreadyRead)
    }

    $offset = $alreadyRead
    while ($offset -lt $contentLength) {
        $read = $Stream.Read($body, $offset, $contentLength - $offset)
        if ($read -le 0) { throw "HTTP request body ended unexpectedly." }
        $offset += $read
    }

    return [PSCustomObject]@{
        Method = $requestParts[0].ToUpperInvariant()
        Target = $requestParts[1]
        Headers = $headers
        Body = $body
    }
}

function Send-HttpResponse {
    param(
        [System.Net.Sockets.NetworkStream]$Stream,
        [int]$StatusCode,
        [string]$StatusText,
        [string]$ContentType,
        [byte[]]$Body
    )

    if ($null -eq $Body) { $Body = New-Object byte[] 0 }
    $header = "HTTP/1.1 $StatusCode $StatusText`r`n" +
        "Content-Type: $ContentType`r`n" +
        "Content-Length: $($Body.Length)`r`n" +
        "Cache-Control: no-store, no-cache, must-revalidate`r`n" +
        "Connection: close`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headerBytes, 0, $headerBytes.Length)
    if ($Body.Length -gt 0) { $Stream.Write($Body, 0, $Body.Length) }
    $Stream.Flush()
}

function Get-MimeType {
    param([string]$Path)
    switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
        ".html" { return "text/html; charset=utf-8" }
        ".js"   { return "application/javascript; charset=utf-8" }
        ".json" { return "application/json; charset=utf-8" }
        ".css"  { return "text/css; charset=utf-8" }
        ".jpg"  { return "image/jpeg" }
        ".jpeg" { return "image/jpeg" }
        ".png"  { return "image/png" }
        ".webp" { return "image/webp" }
        ".gif"  { return "image/gif" }
        ".bmp"  { return "image/bmp" }
        ".avif" { return "image/avif" }
        default  { return "application/octet-stream" }
    }
}

$listener = New-Object -TypeName System.Net.Sockets.TcpListener -ArgumentList ([System.Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
} catch {
    exit 0
}

try {
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $request = Read-HttpRequest -Stream $stream
            if ($null -eq $request) { continue }

            $targetPath = ($request.Target -split "\?", 2)[0]
            if ($targetPath -eq "/health") {
                Send-HttpResponse $stream 200 "OK" "text/plain; charset=utf-8" ($Utf8.GetBytes("OK"))
                continue
            }

            if ($targetPath -eq "/api/state") {
                if ($request.Method -eq "GET") {
                    if (Test-Path -LiteralPath $StateFile -PathType Leaf) {
                        $stateBytes = [System.IO.File]::ReadAllBytes($StateFile)
                    } else {
                        $stateBytes = $Utf8.GetBytes('{"version":1,"appState":null,"cues":[]}')
                    }
                    Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" $stateBytes
                } elseif ($request.Method -eq "POST") {
                    try {
                        $jsonText = $Utf8.GetString($request.Body)
                        $null = $jsonText | ConvertFrom-Json
                        [System.IO.File]::WriteAllBytes($StateFile, $request.Body)
                        Send-HttpResponse $stream 200 "OK" "application/json; charset=utf-8" ($Utf8.GetBytes('{"saved":true}'))
                    } catch {
                        Send-HttpResponse $stream 400 "Bad Request" "application/json; charset=utf-8" ($Utf8.GetBytes('{"saved":false}'))
                    }
                } else {
                    Send-HttpResponse $stream 405 "Method Not Allowed" "text/plain; charset=utf-8" ($Utf8.GetBytes("Method not allowed"))
                }
                continue
            }

            if ($request.Method -ne "GET" -and $request.Method -ne "HEAD") {
                Send-HttpResponse $stream 405 "Method Not Allowed" "text/plain; charset=utf-8" ($Utf8.GetBytes("Method not allowed"))
                continue
            }

            if ($targetPath -eq "/") { $targetPath = "/index.html" }
            $relativePath = [System.Uri]::UnescapeDataString($targetPath.TrimStart("/")).Replace("/", [System.IO.Path]::DirectorySeparatorChar)
            $filePath = [System.IO.Path]::GetFullPath((Join-Path $ScriptDirectory $relativePath))
            if (-not $filePath.StartsWith($RootPath, [System.StringComparison]::OrdinalIgnoreCase)) {
                Send-HttpResponse $stream 403 "Forbidden" "text/plain; charset=utf-8" ($Utf8.GetBytes("Forbidden"))
                continue
            }
            if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
                Send-HttpResponse $stream 404 "Not Found" "text/plain; charset=utf-8" ($Utf8.GetBytes("Not found"))
                continue
            }

            $fileBytes = [System.IO.File]::ReadAllBytes($filePath)
            if ($request.Method -eq "HEAD") { $fileBytes = New-Object byte[] 0 }
            Send-HttpResponse $stream 200 "OK" (Get-MimeType $filePath) $fileBytes
        } catch {
            try {
                Send-HttpResponse $stream 500 "Internal Server Error" "text/plain; charset=utf-8" ($Utf8.GetBytes("Server error"))
            } catch { }
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
}
