[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

$ScriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($ScriptDirectory)) {
    $ScriptDirectory = (Get-Location).Path
}

$Identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$WindowsPrincipal = New-Object Security.Principal.WindowsPrincipal($Identity)
$IsAdmin = $WindowsPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    $ElevationArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $ElevationArgs
    exit
}

$HtmlFile = Join-Path $ScriptDirectory "index.html"
$LauncherBat = Join-Path $ScriptDirectory "SETUP_HTML.bat"
$ManifestBuilder = Join-Path $ScriptDirectory "BUILD_CUTOK_MANIFEST.ps1"
$ServerScript = Join-Path $ScriptDirectory "EXHIBITION_SERVER.ps1"
$ShutdownTaskName = "Exhibition_Daily_Shutdown_0100"
$AutoStartTaskName = "Exhibition_AutoStart_HTML"

if (-not (Test-Path -LiteralPath $HtmlFile -PathType Leaf)) {
    Write-Host "[ERROR] index.html was not found: $HtmlFile" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

if (-not (Test-Path -LiteralPath $LauncherBat -PathType Leaf)) {
    Write-Host "[ERROR] SETUP_HTML.bat was not found: $LauncherBat" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

if (-not (Test-Path -LiteralPath $ManifestBuilder -PathType Leaf)) {
    Write-Host "[ERROR] BUILD_CUTOK_MANIFEST.ps1 was not found: $ManifestBuilder" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

if (-not (Test-Path -LiteralPath $ServerScript -PathType Leaf)) {
    Write-Host "[ERROR] EXHIBITION_SERVER.ps1 was not found: $ServerScript" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

$CurrentUser = [Security.Principal.WindowsIdentity]::GetCurrent().Name

$ShutdownAction = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\shutdown.exe" -Argument "/s /f /t 0"
$ShutdownTrigger = New-ScheduledTaskTrigger -Daily -At ([DateTime]::Today.AddHours(1))
$ShutdownPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$ShutdownSettings = New-ScheduledTaskSettingsSet -WakeToRun -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries

$ShutdownTaskParams = @{
    TaskName = $ShutdownTaskName
    Action = $ShutdownAction
    Trigger = $ShutdownTrigger
    Principal = $ShutdownPrincipal
    Settings = $ShutdownSettings
    Description = "Daily exhibition shutdown at 01:00"
    Force = $true
}
Register-ScheduledTask @ShutdownTaskParams | Out-Null

$AutoStartActionParams = @{
    Execute = "$env:SystemRoot\System32\cmd.exe"
    Argument = ('/d /c call "' + $LauncherBat + '" kiosk')
    WorkingDirectory = $ScriptDirectory
}
$AutoStartAction = New-ScheduledTaskAction @AutoStartActionParams
$AutoStartTrigger = New-ScheduledTaskTrigger -AtLogOn -User $CurrentUser
$AutoStartPrincipal = New-ScheduledTaskPrincipal -UserId $CurrentUser -LogonType Interactive -RunLevel Highest
$AutoStartSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

$AutoStartTaskParams = @{
    TaskName = $AutoStartTaskName
    Action = $AutoStartAction
    Trigger = $AutoStartTrigger
    Principal = $AutoStartPrincipal
    Settings = $AutoStartSettings
    Description = "Open exhibition HTML through SETUP_HTML.bat kiosk after Windows logon"
    Force = $true
}
Register-ScheduledTask @AutoStartTaskParams | Out-Null

$Winlogon = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -ErrorAction SilentlyContinue
$AutoLogonReady = $Winlogon.AutoAdminLogon -eq "1"

Write-Host ""
Write-Host "============================================================"
Write-Host " Exhibition daily schedule installed" -ForegroundColor Green
Write-Host "============================================================"
Write-Host "Daily Windows shutdown: 01:00"
Write-Host "BIOS RTC power-on:       01:02 (manual BIOS setting required)"
Write-Host "HTML auto-start:         after Windows logon"
Write-Host ("HTML:                    " + $HtmlFile)
Write-Host ("Windows time zone:       " + [TimeZoneInfo]::Local.DisplayName)
Write-Host ""

if ($AutoLogonReady) {
    Write-Host "Windows auto-logon: detected" -ForegroundColor Green
} else {
    Write-Host "Windows auto-logon: not detected" -ForegroundColor Yellow
    Write-Host "After BIOS power-on, Windows may stop at the sign-in screen."
    Write-Host "Enable auto-logon for the exhibition account before unattended use."
}

Write-Host ""
Write-Host "Set the motherboard BIOS/UEFI RTC Alarm to DAILY 01:02."
Write-Host "The two-minute gap is short. If RTC boot is unreliable, use 01:05."
Write-Host ""
Write-Host "Starting the HTML auto-start task now for a live test..."
Start-ScheduledTask -TaskName $AutoStartTaskName
Write-Host "Test command sent. Edge Kiosk should open shortly." -ForegroundColor Green
Write-Host "Press Alt+F4 to exit the Kiosk test."
Write-Host ""
Read-Host "Press Enter to close this installer"
