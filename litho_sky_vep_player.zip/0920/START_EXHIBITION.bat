@echo off
REM Compatibility wrapper. The only real launcher is SETUP_HTML.bat.
call "%~dp0SETUP_HTML.bat" kiosk
exit /b %ERRORLEVEL%
