[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$Identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$WindowsPrincipal = New-Object Security.Principal.WindowsPrincipal($Identity)
$IsAdmin = $WindowsPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $IsAdmin) {
    $ElevationArgs = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
    Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $ElevationArgs
    exit
}

@("Exhibition_Daily_Shutdown_0100", "Exhibition_AutoStart_HTML") | ForEach-Object {
    if (Get-ScheduledTask -TaskName $_ -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $_ -Confirm:$false
        Write-Host ("Removed: " + $_) -ForegroundColor Green
    }
}

Read-Host "Press Enter to close"
